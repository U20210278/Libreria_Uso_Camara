package com.example.mostrar_foto_cam_u20210278;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Button btnTomarFoto;
    ImageView imgFoto;
    String rutaImagenes;
    ImageButton ImgWhatSapp, ImgCorreo;
    private static final int REQUEST_CODIGO_CAMARA=200;
    private static final int REQUEST_CODIGO_CAPTURAR_IMAGEN=300;
    /*Fue una buena experiencia aprender de esta libreria ya que no tenia el conocimiento de esta libreria
    * tambien aprendi nuevas coasas porque hubieron problemas con el codigo proporciando en el pdf
    * daba un error pero investigue y se tenia que apregar un permiso mas en la manifest que era el harward de la camara
    * */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        imgFoto = findViewById(R.id.imgFoto);
        btnTomarFoto = findViewById(R.id.btnTomarFoto);
        ImgWhatSapp = findViewById(R.id.ImgWhat);
        ImgCorreo = findViewById(R.id.ImgCorreo);


        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {
            if (ActivityCompat.checkSelfPermission(MainActivity.this,Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            {
                ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},1);
            }
        }

        imgFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentGa = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intentGa,1);
            }
        });




        ImgWhatSapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarPorWhatsApp();
            }
        });

        ImgCorreo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarPorCorreo();
            }
        });



        btnTomarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarProcesoFotografia();

            }
        });

    }

    private void enviarPorWhatsApp() {
        /*Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("image/*");
        //intent.setAction(Intent.ACTION_GET_CONTENT);
        //intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(rutaImagenes)); // ruta de la imagen capturada
        intent.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://" + rutaImagenes));
        intent.setPackage("com.whatsapp"); // Especifica que solo WhatsApp manejará el intent
        startActivity(Intent.createChooser(intent, "Compartir imagen por WhatsApp"));*/

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("image/*");
        intent.setPackage("com.whatsapp");
        intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(rutaImagenes)); // ruta de la imagen capturada
        startActivity(Intent.createChooser(intent, "Compartir imagen por WhatsApp"));
        //intent.putExtra(Intent.EXTRA_STREAM, rutaImagenes);

        if (rutaImagenes != null)
        {
            intent.putExtra(Intent.EXTRA_STREAM, rutaImagenes);

            try{
                startActivity(intent);

            }catch (Exception e)
            {
                Toast.makeText(MainActivity.this,"Error Al Enviar \n"+e.getMessage(),Toast.LENGTH_LONG).show();
            }
        }else
        {
            Toast.makeText(MainActivity.this,"No Se Selecciono la Imagen ",Toast.LENGTH_LONG).show();

        }


    }


    private void enviarPorCorreo() {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_STREAM, Uri.parse(rutaImagenes)); // ruta de la imagen capturada
        intent.putExtra(Intent.EXTRA_SUBJECT, "Asunto del correo"); // Asunto del correo
        intent.putExtra(Intent.EXTRA_TEXT, "Texto del correo"); // Cuerpo del correo
        startActivity(Intent.createChooser(intent, "Compartir imagen por Correo Electrónico"));
    }

    private void realizarProcesoFotografia() {
        if(Build.VERSION.SDK_INT >=Build.VERSION_CODES.N)
        {
            if (ActivityCompat.checkSelfPermission(
                    MainActivity.this, android.Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED){
                tomarFoto();
            }else {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[] {Manifest.permission.CAMERA},REQUEST_CODIGO_CAMARA);

            }
        }else{
            tomarFoto();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CODIGO_CAMARA)
        {
            if (permissions.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                tomarFoto();
            }else {
                Toast.makeText(MainActivity.this , "Se requiere Permiso para la Camara !!", Toast.LENGTH_SHORT).show();
            }

        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_CODIGO_CAPTURAR_IMAGEN)
        {
            //Si capturo la foto
            if(resultCode == Activity.RESULT_OK){
                imgFoto.setImageURI(Uri.parse(rutaImagenes));
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void tomarFoto() {
        Intent intentCamara = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intentCamara.resolveActivity(getPackageManager()) !=null)
        {
            File archivoFoto = null;
            archivoFoto = crearArchivo();
            if (archivoFoto != null){
                Uri rutaFoto = FileProvider.getUriForFile(
                        MainActivity.this,
                        "com.example.mostrar_foto_cam_u20210278",
                        archivoFoto);
                intentCamara.putExtra(MediaStore.EXTRA_OUTPUT,rutaFoto);
                startActivityForResult(intentCamara,REQUEST_CODIGO_CAPTURAR_IMAGEN);
            }
        }

    }

    private File crearArchivo() {
        String nomenclatura = new SimpleDateFormat("yyyyMMdd_HHmmss",
                Locale.getDefault()).format(new Date());
        String prefijoArchivo = "APPCAM_"+nomenclatura + "_";
        File directorioImagen = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File miImagen = null;
        try {
            miImagen = File.createTempFile(prefijoArchivo, ".jpg",directorioImagen);
            rutaImagenes = miImagen.getAbsolutePath();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return  miImagen;


    }


}